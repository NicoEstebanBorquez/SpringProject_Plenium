package com.plenium.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PleniumApplicationTests {

	@Test
	void contextLoads() {
	}

}
